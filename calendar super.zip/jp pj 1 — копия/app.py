
from flask import Flask, render_template, request, redirect, url_for, jsonify
import time
import threading

app = Flask(__name__)

timer_data = {
    'duration': 0,
    'remaining': 0,
    'active': False
}

def timer_thread():
    while timer_data['remaining'] > 0:
        time.sleep(1)
        timer_data['remaining'] -= 1
    timer_data['active'] = False

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        duration = int(request.form['duration'])
        timer_data['duration'] = duration
        timer_data['remaining'] = duration
        timer_data['active'] = True

        threading.Thread(target=timer_thread).start()

        return redirect(url_for('index'))

    return render_template('index.html', timer=timer_data)

@app.route('/clock')
def clock():
    return render_template('clock.html')


@app.route('/status')
def status():
    return jsonify(timer_data)

@app.route('/world-time')
def world_time():
    return render_template('world_time.html')


@app.route('/calendar')
def calendar():
    return render_template('calendar_with_notes.html')

if __name__ == '__main__':
    app.run(debug=True)